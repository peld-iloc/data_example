PELD ILOC REEF FISHES	
VERSION 1.0 2020-08-11	
Revised by Thiago Cesar L. Silveira	

Workflow	

"1. READ this instructions. If you have doubts, READ IT AGAIN. If you cannot find answers yet, please WRITE US. Cesar Cordeiro - cammcordeiro@gmail.com, Marina Sissini - msissini@gmail.com"	
"2. Before to update this file, save it with a differtent name following this format ""peld_iloc_peixes_recifais_Your_Name_YYYY_MM_DD"""	
3. Keep the format indicated for variables on description.	
Variables -	Description
island -	"Island - noronha, rocas, stpaul_rocks, trindade"
site -	Locality where the visual census were done. Pick from dropdown menu.
observer -	"The name of who did the survey. Format - Krajewski, J.P."
lon_DD -	Longitude in decimal degrees. Format: -3.235435. (six decimals) DATUM WGS84
lat_DD -	Latitude in decimal degrees . Format: -33.35435.  (six decimals) DATUM WGS84
day_dd -	"day (01, 02,�) with two numbers. Column formated as text"
month_mm -	"month (05, 06,�) with two numbers. Column formated as text"
year_YYYY -	"year (2015, 2016,�) with four number."
transect_n -	"number of the transect, sequential (1, 2, 3,...)"
transect_id -	id created joining island_year_transect_n (noronha_2007_65)
depth_m -	depth in meters
temp_c  -	temperature in Celsius degrees
observations -	any comment about the survey
visibility_m -	"estimated horizontal visibility, meters"
time_in -	hour when the dive started. !!! needs revision
duration -	Survey time in minutes and seconds. !!! needs revision
code -	species code. Format: abudefduf_saxatilis -> abu_sax - three firt letters of genus and species 
species_name -	"species name. Format: abudefduf_saxatilis - genus and species separated by ""_"""
life_phase -	!!! need srevision
abun -	observed density on transect
size_cm -	observed size
georeferenceProtocol  -	"Coordinates obtained and checked. Obtained based on orthophotography inspection, personal communication and previous studies on sites"
